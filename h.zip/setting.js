module.exports = {
  name: "WANZOFC",
  version: "4.1.0",
  number: "",
  owner: {
    name: "WANZOFC",
    number: "62895402567224",
    whatsapp: "6283870474876@s.whatsapp.net",
    instagram: "https://www.instagram.com/wanz_brayg",
  },
  author: {
    name: "WANZOFC",
    number: "62895402567224",
    whatsapp: "62895402567224@s.whatsapp.net",
    instagram: "https://www.instagram.com/wanz_brayy",
  },
  features: {
    antiCall: {
      status: true,
      block: false,
    },
    selfMode: true,
    broadcast: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContact: false,
    },
    pushContacts: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContacts: false,
    },
  },
};
